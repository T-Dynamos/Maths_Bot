clear
apt update
apt upgrade 
apt install figlet -y
apt install toilet -y
apt install nano -y
apt install ruby -y
apt install curl -y
gem install lolcat
clear
toilet -f pagga "Installing" | lolcat
pip install colorama
pip install requests
pip install table-ex
cd m_bot
toilet -f pagga "Success..!!" | lolcat
python setup.py